<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width,initial-scale=1.0" />
        <meta
            name="keywords"
            content="HOSPITAL,HOSPITAL.COM,HOSPITAL WEBSITE, MEDICAN"
        />
        <meta
            name="description"
            content="india's best hospital website of indian"
        />
        <meta name="author" content="hospital.com" />
        <title>Aurvedic Hospital Management</title>
        <link rel="stylesheet" type="text/css" href="css/index.css" />
        <link
            rel="stylesheet"
            type="text/css"
            href="css/fontawesome/css/all.css"
        />
        <link rel="stylesheet" type="text/css" href="css/animate.css" />
    </head>
    <body>
        <!-- Start Header Coding-->
        <header>
            <div class="menu">
                <!-- Start Brand name coding-->
                <div class="brand-name">
                    <a href="index.html">
                        <h2 class="animated flash">
                            <i class="fa fa-hospital"></i>&nbsp; Aurveda
                        </h2>
                    </a>
                </div>
                <!-- End Brand name coding-->
                <!-- Start Nav coding & menu coding -->
                <nav>
                    <ul>
                        <li><a href="index.html">Home</a></li>
                        <li><a href="gallery.html">Gallery</a></li>
                        <li><a href="Login.html">Doctors Login</a></li>
                        <li><a href="patientLogin.html">Login</a></li>
                        <li><a href="contact.html">Contact Us</a></li>
                    </ul>
                </nav>
                <!-- End Nav coding & menu coding -->
            </div>
        </header>
        <!-- End Header Coding-->
        <!-- Start Section Coding-->
        <section>
            <div class="w-80" style="padding: 0">
                <div class="section-img">
                    <div class="section-bg-box">
                        <h1 class="animated slideInLeft">
                            Health Care Services
                        </h1>
                        <h2 class="animated slideInRight">
                            We Care About Your Health
                        </h2>
                    </div>
                </div>
                <!-- text decoration coding -->
                <br /><br />
                <h1 class="welcome-text">WELCOME TO HOSPITAL SERVICE</h1>
                <br /><br />
                <p>
                    At Medanta, the latest that the technology has to offer
                    works in synergy with the time-tested practice of Ayurveda.
                    Our Department of Integrative Medicine uses science and
                    technology to integrate evidence-based medicine in Ayurveda
                    into the practice of modern medicine. This fusion not only
                    offers therapeutic benefits but also ensures that the
                    patient saves time and money.
                </p>
                <br />
                <p>
                    Following the ethos of Medanta, the Department of
                    Integrative Medicine is using science and technology to
                    integrate evidence-based medicine in Ayurveda into the
                    practice of modern medicine. Medanta has opened the scope to
                    identify, assess and personalise the immense wealth of
                    medical knowledge represented by the science of Ayurveda for
                    patient care and health promotion. Through the unique
                    Prakruti analysis of Ayurveda and co-relating the
                    information to the genetic makeup of a person, Medanta
                    Executive Health Check-up can now predict diseases and offer
                    preventive interventions and lifestyle modifications to its
                    patrons.
                </p>
                <br />
                <p>
                    Phasellus pretium orci sit amet mi ullamcorper egestas. Sed
                    non mattis metus. Integer vel lorem tincidunt, pharetra eros
                    nec, posuere odio. Nullam eget bibendum sem, venenatis
                    lacinia justo. Duis aliquet lobortis neque, eget volutpat
                    nulla iaculis a.
                </p>
                <br />
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                    Soluta, eveniet omnis perferendis assumenda, adipisci eum
                    esse repellat voluptatibus velit, minus sunt odio
                    accusantium natus consequuntur deleniti voluptatum! Magnam,
                    dicta, officiis!
                </p>
                <br />
                <p>
                    Phasellus pretium orci sit amet mi ullamcorper egestas. Sed
                    non mattis metus. Integer vel lorem tincidunt, pharetra eros
                    nec, posuere odio. Nullam eget bibendum sem, venenatis
                    lacinia justo. Duis aliquet lobortis neque, eget volutpat
                    nulla iaculis a.
                </p>
                <br />
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                    Soluta, eveniet omnis perferendis assumenda, adipisci eum
                    esse repellat voluptatibus velit, minus sunt odio
                    accusantium natus consequuntur deleniti voluptatum! Magnam,
                    dicta, officiis!
                </p>
                <br />
                <h1 class="welcome-text">OUR OUTSTANDING SERVICES</h1>
                <br />
                <h2>What We Offer!</h2>

                <ul>
                    <li>Vata Dosha</li>
                    <li>Pitta Dosha</li>
                    <li>Kapha Dosha</li>
                    <li>Panchkarma Therapy</li>
                    <li>Detox Therapy</li>
                    <li>Nervous Disorder Management</li>
                </ul>
                <br />
                <h2>Powerful Ayurvedi Herbs</h2>

                <ul>
                    <li>Ashwagandha</li>
                    <li>Amla</li>
                    <li>Bramhi</li>
                    <li>Cumin</li>
                    <li>Turmeric</li>
                    <li>Bitter Lemon</li>
                    <li>Cardamon</li>
                </ul>
                <br />
                <h1 class="welcome-text" style="width: 25%">about us</h1>
                <br />
                <h2>Best Medical & Health care Needs to Our Patients</h2>
                <div class="about-box">
                    <div>
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit. Ut volutpat rutrum eros amet sollicitudin
                            interdum. Suspendisse pulvinar, velit nec pharetra
                            interdum, ante tellus ornare mi, et mollis tellus
                            neque vitae elit. Mauris adipiscing mauris fringilla
                            turpis interdum sed pulvinar nisi malesuada. Lorem
                            ipsum dolor sit amet, consectetur adipiscing elit.
                        </p>
                        <br />
                        <p>
                            Donec sed odio dui. Nulla vitae elit libero, a
                            pharetra augue. Nullam id dolor id nibh ultricies
                            vehicula ut id elit.
                        </p>
                    </div>
                    <div>
                        <img
                            style=""
                            src="images/3.jpg"
                            width="300"
                            height="400"
                        />
                    </div>
                </div>
            </div>
        </section>
        <!-- End Section Coding-->
        <!-- Start Footer Coding-->
        <footer>
            <div class="w-80">
                <div class="footer-box">
                    <h2>Treatments</h2>
                    <a href="#">Internal Purification Process</a>
                    <a href="#">Special Diet</a>
                    <a href="#">Herbal Remedies</a>
                    <a href="#">Massage Therapy</a>
                    <a href="#">Yoga & Meditation</a>
                </div>
                <div class="footer-box">
                    <h2>About Us</h2>
                    <a href="#">Company Overview</a>
                    <a href="#">Management</a>
                    <a href="#">Initiatives</a>
                    <a href="#">Carrers</a>
                    <a href="#">Our Doctors Achieve</a>
                </div>
                <div class="footer-box">
                    <h2>Contact Us</h2>
                    <a href="#">Post a Query</a>
                    <a href="#">Apollo Clinics</a>
                    <a href="#">Reach Hospitals</a>
                    <a href="#">Apollo Cradle</a>
                    <a href="#">Ask Question</a>
                </div>
                <div class="footer-box">
                    <h2>Facilities</h2>
                    <a href="#">Consultation</a>
                    <a href="#">OPD</a>
                    <a href="#">Pharmacy</a>
                    <a href="#">Panchkarma Theatre</a>
                    <a href="#">physiotheraphy</a>
                </div>
            </div>
        </footer>
        <!-- End footer Coding-->
    </body>
</html>
